import java.io.*;
import java.net.*;

public class MyBrowser {

	public static void main(String[] args) throws Exception {

		String domain = "www.google.com";
		int port = 80;

		if (args.length > 0)
			domain = args[0];

		if (args.length > 1)
			port = Integer.valueOf(args[1]);

		File file1 = new File("head.txt");
		// System.out.println("Got file1");
		File file2 = new File("raw.txt");
		// System.out.println("Got file2");
		File file3 = new File("data.txt");
		// System.out.println("Got file3");

		// *Enter directory for files here
		FileWriter writer1 = new FileWriter(file1);
		FileWriter writer2 = new FileWriter(file2);
		FileWriter writer3 = new FileWriter(file3);

		ServerSocket listener = new ServerSocket(9999);

		Socket sock;

		if (domain == "localhost") {
			sock = listener.accept();
		} else {
			sock = new Socket(domain, port);
		}

		PrintStream out = new PrintStream(sock.getOutputStream());
		InputStreamReader in = new InputStreamReader(sock.getInputStream());

		String req = "GET / HTTP/1.1\nHost: " + domain + "\n\n";
		System.out.println("my http req: " + req);
		String request = "my http req: " + req;
		System.out.println('\n');

		out.print(req);

		boolean eoh = false;
		String head = "";
		String resp = "";
		String data = "";
		int contlen = 219;
		int bodybytes = 0;
		boolean chunked = false;

		int chunks = 0;

		int n = 0;

		for (int b = in.read(); b != -1; b = in.read()) {

			n++;
			if (n > 1500)
				break;

			if (chunks < 1 && eoh && chunked) {
				chunks++;
				System.out.println("!!!!!!! in eof chunked if, time num: " + chunks);
				;
				String hexLen = "" + (char) b;
				hexLen += (char) in.read();
				hexLen += (char) in.read();
				hexLen += (char) in.read();
				int hexLenI = Integer.valueOf(hexLen, 16);
				System.out.println("\n*********\n\nhexLen = " + hexLen + "whichas an int has value: " + hexLenI
						+ "\n\n*********\n");

				b = in.read();

			}

			System.out.print((char) b);
			resp += (char) b;
			data += (char) b;

			if (eoh) {

				bodybytes++;
				if (bodybytes == contlen)
					break;
			}

			if (resp.endsWith("\r\n\r\n") && !eoh) {

				System.out.println("***** at end of header? ***");
				head = resp;
				eoh = true;

				chunked = !head.contains("Content-Length: ");

				if (!chunked) {
					String after = head.split("Content-Length: ")[1];
					String lenStr = after.split("\r")[0];
					contlen = Integer.valueOf(lenStr);
					System.out.println("##### contlen = " + contlen);
				}
			}

			// if (resp.endsWith("Content-Length:"))
			// System.out.println("!!!!!! " + resp);
		}

		System.out.println("head:\n" + head);

		// *Files with the text are automatically placed in the base directory of the
		// project
		writer1.write(request);

		writer2.write(request + data);

		writer3.write(data);

		// System.out.println(data);

		writer1.close();
		writer2.close();
		writer3.close();

		in.close();
		out.close();
		sock.close();

	}
}